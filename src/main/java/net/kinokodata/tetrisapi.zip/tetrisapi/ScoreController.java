import org.springframework.beans.factory.annotation.Autowired;

public class ScoreController {
    @Autowired
    private ScoreRepository scoreRepository;
    
}
